command = '/root/django_env/bin/gunicorn'
pythonpath = '/root/uonfirstaid1'
bind = '206.189.113.80:8000'
workers = 3
