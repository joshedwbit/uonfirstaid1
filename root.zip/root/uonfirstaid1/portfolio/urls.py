from django.contrib import admin
from django.urls import path, include
from  . import views

urlpatterns = [
	path('', views.home, name='portfolio-home'),
	path('socials/', views.socials, name='portfolio-socials'),
	path('cprSteps/', views.cprSteps, name='portfolio-cprSteps'),
	path('support/', views.support, name='portfolio-support'),
]
