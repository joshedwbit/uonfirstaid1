from django.shortcuts import render
from django.http import HttpResponse
def home(request):
    return HttpResponse('Namaste')
#def home(request):
#    return render(request,'portfolio/home.html',{'title':'Home'})
def socials(request):
    return render(request,'portfolio/socials.html',{'title':'Socials'})
def cprSteps(request):
    return render(request,'portfolio/cprSteps.html',{'title':'cprSteps'})
def support(request):
    return render(request,'portfolio/support.html',{'title':'Support'})


# Create your views here.
